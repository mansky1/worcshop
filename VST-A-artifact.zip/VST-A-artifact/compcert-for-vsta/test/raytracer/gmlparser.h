/* Parser for GML */

struct array * parse_program(void);
