typedef struct xs X;

struct xs {
  X *x; 
} x0;
